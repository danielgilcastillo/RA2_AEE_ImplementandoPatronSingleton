package ra2_aee_implementacionsingleton;

import java.util.ArrayList;

public class RA2_AEE_ImplementacionSingleton {

    public static void main(String[] args) {
     
        // PROBAMOS A PEDIR UN OBJETO DE USUARIOMANAGER
        // NOS VA A DEVOLVER LA INSTANCIA UNICA TRAS HABERLA CREADO
        UsuarioManager m = UsuarioManager.dameElObjetoUnico();

        // VOLVEMOS A PEDIR UN OBJETO DE USUARIOMANAGER
        // NOS VA A DEVOLVER LA INSTANCIA UNICA QUE YA TENIA CREADA
        UsuarioManager k = UsuarioManager.dameElObjetoUnico();

        // PEDIMOS UNA LISTA DE USUARIOS
        ArrayList<Usuario> listausuarios = m.consultarUsuarios();
        for(Usuario u : listausuarios){
            System.out.println(u);
        }
        System.out.println("--------------------------");
        
        // PEDIR QUE NOS BUSQUE UN USUARIO POR SU ID
        Usuario u1 = k.consultarUnUsuario(2);
        System.out.println(u1);
        Usuario u2 = k.consultarUnUsuario(89);
        System.out.println(u2);
        
        
        
        
        
        
    }

}
