package ra2_aee_implementacionsingleton;

import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UsuarioManager {

    private static String conexionDB = "jdbc:mysql://localhost:3306/";  // esto es para usar MySql
    private static String nombreBD = "usuariossingleton";  // aqui viene el nombre de la base de datos
    private static String usuarioDB = "root";  // usuariode bbdd
    private static String passwordDB = "";   // pwd de la bbdd
    private static Connection miConexion;
    private static UsuarioManager objetoUnico = null;
    private static ArrayList<Usuario> listausuarios = new ArrayList<>();

    private UsuarioManager() {
    }

    public static UsuarioManager dameElObjetoUnico() {
        if (objetoUnico == null) {
            objetoUnico = new UsuarioManager();

            // conectamos a la base de datos
            try {
                miConexion = DriverManager.getConnection(conexionDB + nombreBD, usuarioDB, passwordDB);
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            // leemos los registros y los metemos en una lista de clase Usuario 
            try {
                String sql = "SELECT * FROM USUARIOS";
                PreparedStatement instruccion = miConexion.prepareStatement(sql);
                ResultSet registros = instruccion.executeQuery();
                while (registros.next()) {
                    int cod = registros.getInt("id");
                    String nombre = registros.getString("nombre");
                    String email = registros.getString("email");
                    
                    Usuario u = new Usuario(cod, nombre, email);
                    objetoUnico.listausuarios.add(u);
                }
                
            } catch (SQLException ex) {
                ex.printStackTrace();
            } finally {
                try {
                    miConexion.close();
                } catch (SQLException ex) {
                    Logger.getLogger(UsuarioManager.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }
        return objetoUnico;
    }

    
    
    public ArrayList<Usuario> consultarUsuarios(){
        return listausuarios;
        
    }
    
    
    
    public Usuario consultarUnUsuario(int idpedido){
        for(Usuario u : listausuarios){
            if(u.getId()==idpedido){
                return u;
            }
        }
        return null;
    }
    
 
}
